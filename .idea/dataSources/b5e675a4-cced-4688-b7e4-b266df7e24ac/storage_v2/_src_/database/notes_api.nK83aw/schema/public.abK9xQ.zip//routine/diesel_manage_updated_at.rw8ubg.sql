create function diesel_manage_updated_at(_tbl regclass) returns void
    language plpgsql
as
$$
BEGIN
    EXECUTE format('CREATE TRIGGER set_updated_at BEFORE UPDATE ON %s
                    FOR EACH ROW EXECUTE PROCEDURE diesel_set_updated_at()', _tbl);
END;
$$;

alter function diesel_manage_updated_at(regclass) owner to postgres;

